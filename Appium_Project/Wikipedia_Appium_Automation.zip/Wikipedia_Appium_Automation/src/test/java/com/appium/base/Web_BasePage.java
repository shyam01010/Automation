package com.appium.base;

public class Web_BasePage {
}
