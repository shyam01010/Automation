package constants;

public enum EnvironmentType {
    NATIVE,
    WEB,
    HYBRID,
    IOS
}
