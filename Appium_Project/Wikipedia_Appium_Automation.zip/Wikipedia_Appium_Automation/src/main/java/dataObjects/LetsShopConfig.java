package dataObjects;

public class LetsShopConfig {

    private String userName;
    private String countryDropdown;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCountryDropdown() {
        return countryDropdown;
    }

    public void setCountryDropdown(String countryDropdown) {
        this.countryDropdown = countryDropdown;
    }



}
